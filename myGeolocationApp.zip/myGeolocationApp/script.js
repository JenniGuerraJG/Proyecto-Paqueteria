var swiper = new Swiper(".mySwiper-1",{
    slidesPerView:1,
    spaceBetween: 30,
    loop:true,
    pagination:{
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation:{
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});

var swiper = new Swiper(".mySwiper-2",{
    slidesPerView: 3,
    spaceBetween:20,
    loop:true,
    loopFillGroupWithBlank: true,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

    brekpoints: {
        0:{
            slidesPerView:1,
        },
        520:{
            slidesPerView:2,
        },
        950: {
            slidesPerView:3,
        }
    }
});



let tabInputs = document.querySelectorAll(".tabInput");

tabInputs.forEach(function(input) {
    input.addEventListener('change', function() {
        let id = input.getAttribute('ariaValueMax'); // Corregido el acceso al atributo
        let thisSwiper = document.getElementById('swiper' + id);
        thisSwiper.swiper.update();
    })
});

$(document).ready(function(){
    $('#track-button').click(function(event){
        event.preventDefault(); // Evitar que el enlace realice una acción predeterminada

        // Abrir una nueva pestaña con el contenido del segundo HTML
        var nuevaPestana = window.open("file:///C:/Users/jenni/OneDrive/Desktop/myGeolocationApp/index.html#", "_blank");

        // Si necesitas cerrar la ventana actual después de abrir la nueva pestaña
        // window.close();
    });
});

$(document).ready(function(){
    // Botón de "Inicio"
    $('a[href="#inicio"]').on('click', function(event) {
        event.preventDefault();
        // Navegar a la sección de inicio
        $('html, body').animate({
            scrollTop: 0
        }, 800);
    });

    // Botón de "Servicios"
    $('a[href="#servicios"]').on('click', function(event) {
        event.preventDefault();
        // Navegar a la sección de servicios
        $('html, body').animate({
            scrollTop: $('#servicios').offset().top
        }, 800);
    });

    // Botón de "Horario"
    $('a[href="#horario"]').on('click', function(event) {
        event.preventDefault();
        // Navegar a la sección de horario
        $('html, body').animate({
            scrollTop: $('#horario').offset().top
        }, 800);
    });
});