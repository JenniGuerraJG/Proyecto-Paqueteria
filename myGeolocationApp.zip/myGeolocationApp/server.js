const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); // Importa el paquete cors
const axios = require('axios');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Agrega cors como middleware
app.use(cors());

// Mapeo de códigos a claves API
const apiKeys = {
    'SH': '6fe3b178eaf3423e8c096400dbf36152',
    'SQ': 'cf6553d54ff04c799682c4f0a31a2361',
    'SO': 'fc5b1648902b487f96e9a8ae5026679f'
};

app.post('/location', async (req, res) => {
    const { lat, lon, code } = req.body;
    const apiKey = apiKeys[code];

    if (!apiKey) {
        return res.status(400).json({ message: 'Código inválido.' });
    }

    try {
        const apiUrl = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lon}&key=${apiKey}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.results && data.results.length > 0) {
            const city = data.results[0].components.city || data.results[0].components.town || data.results[0].components.village;
            if (city) {
                return res.json({ message: `Ciudad: ${city}` });
            } else {
                return res.json({ message: 'No se pudo determinar la ciudad.' });
            }
        } else {
            return res.json({ message: 'No se encontraron resultados.' });
        }
    } catch (error) {
        return res.status(500).json({ message: 'Error al comunicarse con la API de OpenCage.' });
    }
});

app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});