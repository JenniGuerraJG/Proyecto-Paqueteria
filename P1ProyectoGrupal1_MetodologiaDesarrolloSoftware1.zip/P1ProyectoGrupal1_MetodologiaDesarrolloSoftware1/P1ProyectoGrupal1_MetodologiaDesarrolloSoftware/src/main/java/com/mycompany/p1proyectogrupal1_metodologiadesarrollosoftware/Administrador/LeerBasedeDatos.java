/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.p1proyectogrupal1_metodologiadesarrollosoftware.Administrador;

import com.mongodb.client.FindIterable;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class LeerBasedeDatos extends MongoConnection{
    public void leerColeccion(JTable table, String CollectName) {
        Connect(CollectName); // Conectar a la colección "PaquetesBodega"
        
        // Crear modelo de tabla con columnas para Remitente, Destinatario, Paquete y Repartidor
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Remitente");
        model.addColumn("Destinatario");
        model.addColumn("Paquete");
        model.addColumn("Repartidor");

        // Obtener todos los documentos de la colección
        FindIterable<Document> documents = getCollection().find();

        // Verificar si se encontraron documentos
        if (documents != null) {
            // Iterar sobre cada documento encontrado
            for (Document document : documents) {
                // Obtener los documentos anidados de remitente, destinatario, paquete y repartidor
                Document remitente = document.get("remitente", Document.class);
                Document destinatario = document.get("destinatario", Document.class);
                Document paquete = document.get("paquete", Document.class);
                Document repartidor = document.get("repartidor", Document.class);

                // Construir las cadenas con la información de cada sección
                String remitenteInfo = remitente.getString("nombre") + ", " +
                        remitente.getString("cedula") + ", " +
                        remitente.getString("telefono");

                String destinatarioInfo = destinatario.getString("nombre") + ", " +
                        destinatario.getString("cedula") + ", " +
                        destinatario.getString("telefono");

                String paqueteInfo = paquete.getString("ciudadEnvio") + ", " +
                        paquete.getString("direccion") + ", " +
                        paquete.getString("dimensiones") + ", " +
                        paquete.getString("peso") + ", " +
                        paquete.getString("Tarifa") + ", " +
                        paquete.getString("CodigoRastreo");

                String repartidorInfo = repartidor.getString("nombre") + ", " +
                        repartidor.getString("ID") + ", " +
                        repartidor.getString("Placa");

                // Agregar una nueva fila al modelo de la tabla con la información obtenida
                model.addRow(new Object[]{remitenteInfo, destinatarioInfo, paqueteInfo, repartidorInfo});
            }

            // Establecer el modelo de la tabla con los datos obtenidos
            table.setModel(model);
        } else {
            // Mostrar mensaje de error si no se encontraron documentos
            JOptionPane.showMessageDialog(null, "No se han registrado paquetes", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }       
}
