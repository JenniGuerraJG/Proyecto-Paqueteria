
package com.mycompany.p1proyectogrupal1_metodologiadesarrollosoftware;

import com.mycompany.p1proyectogrupal1_metodologiadesarrollosoftware.Administrador.Panel_Administrador;

public class P1ProyectoGrupal1_MetodologiaDesarrolloSoftware {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Panel_Administrador pad=new Panel_Administrador();
        pad.setVisible(true);
    }
}
