/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.p1proyectogrupal1_metodologiadesarrollosoftware.Administrador;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Factura {
    public void factura(String Code, String NameR, String ID_R, String CellR,String NameD, String ID_D, String Cell_D, String NameT, String ID_T, String PlacaT, String City, String Direction, String Dimentions, String Weigth, String Tarifa){
        Document document = new Document();
        try {
            // Especificar el archivo de salida
            PdfWriter.getInstance(document, new FileOutputStream("Factura"+Code+".pdf"));
            // Abrir el documento para escritura
            document.open();
            document.add(new Paragraph("========================================================================="));
            // Agregar imagen al documento
            String imagePath = "src/main/resources/imagenes/Logo1.png"; 
            Image logo = Image.getInstance(imagePath);
            logo.scaleToFit(200, 60); // Escalar la imagen si es necesario
            logo.setAlignment(Image.ALIGN_CENTER);
            document.add(logo);
            // Agregar contenido al documento
            document.add(new Paragraph("=================================FACTURA================================="));
            document.add(new Paragraph(""));
            document.add(new Paragraph("Remitente:"));
            document.add(new Paragraph("Nombre: "+NameR));
            document.add(new Paragraph("Cédula: "+ID_R));
            document.add(new Paragraph("Teléfono: "+CellR));
            document.add(new Paragraph("-------------------------------------------------------------------------"));
            document.add(new Paragraph("Destinatario:"));
            document.add(new Paragraph("Nombre: "+NameD));
            document.add(new Paragraph("Cédula: "+ID_D));
            document.add(new Paragraph("Teléfono :"+Cell_D));
            document.add(new Paragraph("-------------------------------------------------------------------------"));
            document.add(new Paragraph("Repartidor: "));
            document.add(new Paragraph("Nombre: "+NameT));
            document.add(new Paragraph("ID: "+ID_T));
            document.add(new Paragraph("Placa: "+PlacaT));
            document.add(new Paragraph("-------------------------------------------------------------------------"));
            document.add(new Paragraph("Paquete:"));
            document.add(new Paragraph("Ciudad de envío: "+City));
            document.add(new Paragraph("Dirección: "+Direction));
            document.add(new Paragraph("Dimensiones: "+Dimentions));
            document.add(new Paragraph("Peso: "+Weigth));
            document.add(new Paragraph("========================================================================="));
            document.add(new Paragraph("Tarifa: "+Tarifa));
           
            
            // Cerrar el documento
            document.close();
            JOptionPane.showMessageDialog(null, "Datos registrados y factura generada: " + "Factura"+Code+".pdf", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("PDF creado exitosamente.");

        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        }
    }
}
