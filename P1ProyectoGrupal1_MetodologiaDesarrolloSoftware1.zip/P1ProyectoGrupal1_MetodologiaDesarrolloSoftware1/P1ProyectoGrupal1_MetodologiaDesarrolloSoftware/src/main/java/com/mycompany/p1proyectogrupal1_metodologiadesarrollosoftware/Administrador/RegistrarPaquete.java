package com.mycompany.p1proyectogrupal1_metodologiadesarrollosoftware.Administrador;

import java.util.Random;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class RegistrarPaquete extends MongoConnection{
    Factura ft=new Factura();
    public void RegistroEnvio (JTextField NameR, JTextField ID_R, JTextField CellR, JTextField NameD, JTextField ID_D, JTextField CellD, JComboBox PlaceCombo, JTextField Direction, JComboBox DimentionsComboBox, JTextField Weight,JTextField Tarifa, JComboBox NameC, JTextField ID_T,JTextField PlacaT){
        String Code=generateCode(String.valueOf(NameC.getSelectedItem().toString()));
        Connect("PaquetesBodega");
         // Crear documento anidado para el remitente
        Document remitente = new Document("nombre", NameR.getText())
                .append("cedula", ID_R.getText())
                .append("telefono", CellR.getText());

        // Crear documento anidado para el destinatario
        Document destinatario = new Document("nombre", NameD.getText())
                .append("cedula", ID_D.getText())
                .append("telefono", CellD.getText());

        // Crear documento anidado para el paquete
        Document paquete = new Document("ciudadEnvio", PlaceCombo.getSelectedItem().toString())
                .append("direccion", Direction.getText())
                .append("dimensiones", DimentionsComboBox.getSelectedItem().toString())
                .append("peso", Weight.getText())
                .append("Tarifa",Tarifa.getText())
                .append("CodigoRastreo", Code);

        Document repartidor=new Document("nombre",NameC.getSelectedItem().toString())
                .append("ID",ID_T.getText())
                .append("Placa",PlacaT.getText());
        // Crear documento principal y agregar los documentos anidados
        Document document = new Document("remitente", remitente)
                .append("destinatario", destinatario)
                .append("paquete", paquete)
                .append("repartidor", repartidor);
                //.append("codigo del paquete", code);
        // Insertar documento en la colección
        getCollection().insertOne(document);
        
        ft.factura(Code, NameR.getText(), ID_R.getText(), CellR.getText(), NameD.getText(), ID_D.getText(), CellD.getText(), NameC.getSelectedItem().toString(), ID_T.getText(), PlacaT.getText(), PlaceCombo.getSelectedItem().toString(), Direction.getText(), DimentionsComboBox.getSelectedItem().toString(), Weight.getText(), Tarifa.getText());
        Connect("Historial");
        getCollection().insertOne(document);
        
        
    }
    public static String generateCode(String persona) {
        Random random = new Random();

        // Arreglo de letras iniciales permitidas
        String letraInicial;
        switch (persona) {
            case "José David Torres Fernandes":
                letraInicial = "SH";
                break;
            case "Michael Steven Sanchez Vasquez":
                letraInicial = "SQ";
                break;
            case "Billy Alexander Morales Carrillo":
                letraInicial = "SO";
                break;
            default:
                throw new IllegalArgumentException("Número de persona inválido. Debe ser 1, 2 o 3.");
        }

        // Generar 4 números aleatorios
        int numero = random.nextInt(9000) + 1000; // Asegura que el número tenga 4 dígitos

        // Combinar letras y números en el formato deseado
        return letraInicial + numero;
    }
    
}
